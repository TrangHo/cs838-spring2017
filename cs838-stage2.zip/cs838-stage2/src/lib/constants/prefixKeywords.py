PREFIX_KEYWORDS = [
  "attend",
  "attended",
  "recieve",
  "recieved",
  "M.B.A",
  "degree",
  "master",
  "bachelor"
]
